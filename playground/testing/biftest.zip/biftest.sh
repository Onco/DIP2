#!/bin/bash  

java -Djava.library.path="./dist/lib/" -jar ./dist/TestDetectors.jar $@
